import copy
import math
from typing import Optional

import numpy as np
import torch

from codes.env.polynomial_environment import PolynomialEnvironment


class PolyNode:
    def __init__(self, env: PolynomialEnvironment, parent=None, prior=0.0, action_taken: Optional[int] = None):
        self.env = env
        self.parent = parent
        self.children = {}
        self.prior = prior
        self.action_taken = action_taken
        self.N = 0
        self.W = 0.0
        self.Q = 0.0
        self.is_terminal = env.is_terminate()

    def expand(self, policy_priors: np.ndarray):
        mask = self.env.get_network_input()[2]
        valid_actions = np.where(mask)[0]
        for a in valid_actions:
            self.children[a] = PolyNode(
                env=self._next_env(a),
                parent=self,
                prior=float(policy_priors[a]),
                action_taken=int(a),
            )

    def _next_env(self, action_idx: int) -> PolynomialEnvironment:
        new_env = self.env.clone()
        new_env.step(action_idx)
        return new_env

    def is_expanded(self):
        return len(self.children) > 0


class PolynomialMCTS:
    """
    Minimal MCTS that works with PolynomialEnvironment and a policy/value network.
    Supports virtual loss for parallel simulations.
    """

    def __init__(self, net, simulations: int = 50, c_puct: float = 1.0, device: str = "cpu", virtual_loss: float = 1.0):
        self.net = net
        self.simulations = simulations
        self.c_puct = c_puct
        self.device = device
        self.virtual_loss = virtual_loss  # Penalty for nodes being explored in parallel

    def run(self, root_env: PolynomialEnvironment):
        root = PolyNode(env=root_env)

        for _ in range(self.simulations):
            node = root
            path = [node]
            # Selection (with virtual loss applied)
            while node.is_expanded() and not node.is_terminal:
                node = self._select(node)
                path.append(node)
            
            # Apply virtual loss to discourage parallel threads from exploring same path
            for n in path:
                n.W -= self.virtual_loss
                n.Q = n.W / n.N if n.N > 0 else 0.0

            # Evaluation
            value = self._evaluate(node)

            # Backprop (removes virtual loss and adds real value)
            self._backprop(path, value)

        # Choose best child by visit count
        if not root.children:
            # No valid children; pick invalid token to force termination
            policy = np.ones(self.net.action_dim, dtype=np.float32) / self.net.action_dim
            return 0, policy

        visits = np.zeros(self.net.action_dim, dtype=np.float32)
        root_mask = root.env.get_network_input()[2]
        for child in root.children.values():
            visits[child.action_taken] = child.N
        visits[~root_mask] = 0.0
        total = visits.sum()
        policy = visits / total if total > 0 else visits
        best_action = int(np.argmax(visits))
        return best_action, policy

    # ------------------------------------------------------------------ helpers
    def _select(self, node: PolyNode) -> PolyNode:
        total_N = sum(child.N for child in node.children.values()) + 1e-8
        best_score, best_child = -1e9, None
        for child in node.children.values():
            u = self.c_puct * child.prior * math.sqrt(total_N) / (1 + child.N)
            score = child.Q + u
            if score > best_score:
                best_score, best_child = score, child
        return best_child

    def _evaluate(self, node: PolyNode) -> float:
        if node.is_terminal:
            return node.env.accumulate_reward

        tensors, scalars, mask = node.env.get_network_input()
        tensors = np.expand_dims(tensors, axis=0)
        scalars = np.expand_dims(scalars, axis=0)
        mask_batch = np.expand_dims(mask, axis=0)

        self.net.set_mode("infer")
        actions, probs, values = self.net(
            tensors=tensors,
            scalars=scalars,
            mask=torch.from_numpy(mask_batch).to(self.device),
        )
        policy_priors = probs[0].detach().cpu().numpy()
        node.expand(policy_priors)

        return float(values[0].detach().cpu().item())

    def _backprop(self, path, value: float):
        for node in reversed(path):
            node.N += 1
            node.W += value + self.virtual_loss  # Remove virtual loss and add real value
            node.Q = node.W / node.N
            value = value  # value is same for all ancestors here
