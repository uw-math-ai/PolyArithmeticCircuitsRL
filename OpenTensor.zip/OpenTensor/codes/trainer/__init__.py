from codes.trainer.Trainer import *
from codes.trainer.Player import *